<?php $__env->startSection('title', 'Receitas'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Cadastro de Receitas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="/incomes" method="POST" class="form-horizontal">
    <!-- sem <?php echo csrf_field(); ?> o form não é enviado  -->
    <?php echo csrf_field(); ?>

    <fieldset>


        <!-- Value input-->
        <div class="form-group">
            <label class="col-md-6 control-label " for="value" id="value">Valor</label>
            <div class="col-md-4">
                <input type="number" step="0.01" id="value" name="value" min="0.01" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

        <!-- Date input-->
        <div class="form-group">
            <label class="col-md-6 control-label" for="date" id="date">Data</label>
            <div class="col-md-4">
                <input id="date" name="date" type="date" class="form-control input-md">

            </div>
        </div>


        <!-- Message -->
        <div class="form-group">
            <label class="col-md-4 control-label" for="message" id="message">Mensagem</label>
            <div class="col-md-4">
                <textarea class="form-control" id="description" name="description"></textarea>
            </div>
        </div>


        <!-- Buttom Submit -->
        <input class="btn btn-primary" type="submit" value="Salvar">



    </fieldset>
</form>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('teste');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel_sistema_financas\resources\views/incomes/income.blade.php ENDPATH**/ ?>