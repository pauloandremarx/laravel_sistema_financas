<li class="nav-item">
    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
        <i class="fas fa-expand-arrows-alt"></i>
    </a>
</li>
<?php /**PATH C:\wamp64\www\Laravel-TCC-main\Laravel-TCC-main\resources\views/vendor/adminlte/partials/navbar/menu-item-fullscreen-widget.blade.php ENDPATH**/ ?>