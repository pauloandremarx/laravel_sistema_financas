<?php $__env->startSection('title', 'Edição de Gastos'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Painel de Controle</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form action="/expenses/update/<?php echo e($expense->id); ?>" method="POST" class="form-horizontal">
        <!-- sem <?php echo csrf_field(); ?> o form não é enviado  -->
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <fieldset>


            <!-- Form Name -->
            <legend class="bi bi-wallet">Edição de Gastos</legend>


            <!-- Value input-->
            <div class="form-group">
                <label class="col-md-6 control-label " for="value" id="value">Valor</label>
                <div class="col-md-4">
                    <input type="number" step="0.01" id="value" name="value" min="0.01" placeholder="" class="form-control input-md" required="" value="<?php echo e($expense->value); ?>">

                </div>
            </div>

            <!-- Date input-->
            <div class="form-group">
                <label class="col-md-6 control-label" for="date" id="date">Data</label>
                <div class="col-md-4">
                    <input id="date" name="date" type="date" class="form-control input-md" value="<?php echo e($expense->date->format('Y-m-d')); ?>">

                </div>
            </div>

            <!-- Seletor de categoria-->
            <div class="form-group">
                <label for="title">Adicione as Categorias:</label>
                <div class="form-group">
                    <input type="checkbox" name="types[]" value="Educação"> Educação
                </div>
                <div class="form-group">
                    <input type="checkbox" name="types[]" value="Moradia"> Moradia
                </div>
                <div class="form-group">
                    <input type="checkbox" name="types[]" value="Pagamentos"> Pagamentos
                </div>
                <div class="form-group">
                    <input type="checkbox" name="types[]" value="Saúde"> Saúde
                </div>
                <div class="form-group">
                    <input type="checkbox" name="types[]" value="Transporte"> Transporte
                </div>
            </div>


            <!-- Message -->
            <div class="form-group">
                <label class="col-md-4 control-label" for="message" id="message">Mensagem</label>
                <div class="col-md-4">
                    <textarea class="form-control" id="description" name="description" value="<?php echo e($expense->description); ?>"></textarea>
                </div>
            </div>


            <!-- Buttom Submit -->
            <input class="btn btn-primary" type="submit" value="Editar">



        </fieldset>
    </form>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel_sistema_financas\resources\views/expenses/editExpenses.blade.php ENDPATH**/ ?>